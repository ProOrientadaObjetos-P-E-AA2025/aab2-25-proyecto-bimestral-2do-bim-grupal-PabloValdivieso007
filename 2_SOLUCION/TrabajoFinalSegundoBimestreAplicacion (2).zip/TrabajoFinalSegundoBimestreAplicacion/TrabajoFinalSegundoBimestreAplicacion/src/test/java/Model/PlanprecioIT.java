package Model;

public class PlanprecioIT {
    public double getprecioplanes(String plan1, String plan2) {
        double total = 0.0;

        Plan p1 = getPlan(plan1);
        if (p1 != null) {
            total += p1.getprecio();
        }
        if (plan2 != null && !plan2.isEmpty()) {
            Plan p2 = getPlan(plan2);
            if (p2 != null) {
                total += p2.getprecio();
            }
        }

        return total;
    }

    private Plan getPlan(String nombrePlan) {
        if (nombrePlan == null) return null;
        switch (nombrePlan) {
            case "Racconomic":
                return (Plan) new Racconomic();
            case "RaccoonStar":
                return (Plan) new RaccoonStar();
            case "OnlineRaccoon":
                return (Plan) new OnlineRaccoon();
            case "InternationalRaccoon":
                return (Plan) new InternationalRaccoon();
            default:
                return null;
        }
    }
    public interface Plan {
        double getprecio();
    }
}
