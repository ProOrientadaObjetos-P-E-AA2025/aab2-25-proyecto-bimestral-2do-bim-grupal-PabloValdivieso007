/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Model;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ASUS
 */
public class OnlineRaccoonIT {
   
    @Test
    public void testGetprecio() {
        OnlineRaccoon instance = new OnlineRaccoon();
        double expResult = 16.4;
        double result = instance.getprecio();
        assertEquals("OnlineRaccoon debería devolver 16.4", expResult, result, 1e-6);
    }
}
