/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package Model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author ASUS
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
    Model.RacconomicIT.class,
    Model.DescuentoIT.class,
    Model.DescuentoDiscapacidadIT.class,
    Model.OnlineRaccoonIT.class,
    Model.TotalIT.class,
    Model.DescuentoMayorEdadIT.class,
    Model.SubtotalIT.class,
    Model.InternationalRaccoonIT.class,
    Model.DescuentoNingunoIT.class,
    Model.PlanprecioIT.class,
    Model.ClienteIT.class,
    Model.DescuentoAmbasIT.class,
    Model.RaccoonStarIT.class
})
public class ModelITSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
