package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class ClienteIT {

    @Test
    public void testId() {
        Cliente c = new Cliente();
        c.setId(42L);
        assertEquals(Long.valueOf(42L), c.getId());
    }

    @Test
    public void testNombre() {
        Cliente c = new Cliente();
        c.setNombre("Ana Pérez");
        assertEquals("Ana Pérez", c.getNombre());
    }

    @Test
    public void testCedula() {
        Cliente c = new Cliente();
        c.setCedula("12345678");
        assertEquals("12345678", c.getCedula());
    }

    @Test
    public void testFechaNac() {
        Cliente c = new Cliente();
        c.setFecha_nac("1990-05-10");
        assertEquals("1990-05-10", c.getFecha_nac());
    }

    @Test
    public void testCiudad() {
        Cliente c = new Cliente();
        c.setCiudad("Quito");
        assertEquals("Quito", c.getCiudad());
    }

    @Test
    public void testDireccion() {
        Cliente c = new Cliente();
        c.setDireccion("Av. Siempre Viva 742");
        assertEquals("Av. Siempre Viva 742", c.getDireccion());
    }

    @Test
    public void testNumTel() {
        Cliente c = new Cliente();
        c.setNumTel("0987654321");
        assertEquals("0987654321", c.getNumTel());
    }

    @Test
    public void testMarcaModelo() {
        Cliente c = new Cliente();
        c.setMarca("Samsung");
        c.setModelo("Galaxy S21");
        assertEquals("Samsung", c.getMarca());
        assertEquals("Galaxy S21", c.getModelo());
    }

    @Test
    public void testDiscapacidad() {
        Cliente c = new Cliente();
        c.setDiscapacidad("Si");
        assertEquals("Si", c.getDiscapacidad());
    }

    @Test
    public void testPlanes() {
        Cliente c = new Cliente();
        c.setPlan1("Racconomic");
        c.setPlan2("Raccoon Star");
        assertEquals("Racconomic", c.getPlan1());
        assertEquals("Raccoon Star", c.getPlan2());
    }

    @Test
    public void testSubtotalTotal() {
        Cliente c = new Cliente();
        c.setSubtotal(50.75);
        c.setTotal(59.85);
        assertEquals(50.75, c.getSubtotal(), 1e-6);
        assertEquals(59.85, c.getTotal(), 1e-6);
    }
}
