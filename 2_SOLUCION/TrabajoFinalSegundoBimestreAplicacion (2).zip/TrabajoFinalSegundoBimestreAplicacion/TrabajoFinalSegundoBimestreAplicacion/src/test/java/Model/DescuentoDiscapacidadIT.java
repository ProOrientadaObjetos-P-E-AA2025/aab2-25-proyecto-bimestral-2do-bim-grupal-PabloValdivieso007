package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class DescuentoDiscapacidadIT {

    
    @Test
    public void testGetDescuento() {
        DescuentoDiscapacidad instance = new DescuentoDiscapacidad();
        double expResult = 0.25;
        double result = instance.getDescuento();
        assertEquals("DescuentoDiscapacidad debería ser 0.25", expResult, result, 1e-6);
    }
}
