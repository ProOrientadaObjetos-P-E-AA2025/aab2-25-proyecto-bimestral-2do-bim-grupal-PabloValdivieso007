/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Model;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ASUS
 */
public class RacconomicIT {
    
   
    @Test
    public void testGetprecio() {
        Racconomic instance = new Racconomic();
        double expResult = 13.5;
        double result = instance.getprecio();
        assertEquals("Racconomic debería devolver 13.5", expResult, result, 1e-6);
    }
}
