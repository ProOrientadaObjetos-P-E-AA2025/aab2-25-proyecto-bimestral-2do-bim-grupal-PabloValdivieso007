package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class DescuentoMayorEdadIT {

    
    @Test
    public void testGetDescuento() {
        DescuentoMayorEdad instance = new DescuentoMayorEdad();
        double expResult = 0.50;
        double result = instance.getDescuento();
        assertEquals("DescuentoMayorEdad debería ser 0.50", expResult, result, 1e-6);
    }
}
