package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class DescuentoAmbasIT {

    @Test
    public void testGetDescuento() {
        DescuentoAmbas instance = new DescuentoAmbas();
        double expResult = 0.75;
        double result = instance.getDescuento();
        assertEquals("DescuentoAmbas debería ser 0.75", expResult, result, 1e-6);
    }
}
