package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class InternationalRaccoonIT {

    @Test
    public void testGetprecio() {
        InternationalRaccoon instance = new InternationalRaccoon();
        double expResult = 15.00;
        double result = instance.getprecio();
        assertEquals("InternationalRaccoon debería devolver 15.00", expResult, result, 1e-6);
    }
}
