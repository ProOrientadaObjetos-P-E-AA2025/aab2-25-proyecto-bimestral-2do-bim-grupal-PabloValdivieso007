/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Model;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ASUS
 */
public class SubtotalIT {
    
    
    @Test
    public void testCalcularSubtotal() {
        Subtotal instance = new Subtotal();
        
        assertEquals(0.0, instance.calcularSubtotal("", "", 30, false), 1e-6);
        
        assertEquals(13.5, instance.calcularSubtotal("Racconomic", "", 30, false), 1e-6);
        
        assertEquals(29.5, instance.calcularSubtotal("Racconomic", "RaccoonStar", 30, false), 1e-6);
        
        assertEquals(22.125, instance.calcularSubtotal("Racconomic", "RaccoonStar", 30, true), 1e-6);
        
        assertEquals(14.75, instance.calcularSubtotal("Racconomic", "RaccoonStar", 65, false), 1e-6);
        
        assertEquals(7.375, instance.calcularSubtotal("Racconomic", "RaccoonStar", 65, true), 1e-6);
    }
}
