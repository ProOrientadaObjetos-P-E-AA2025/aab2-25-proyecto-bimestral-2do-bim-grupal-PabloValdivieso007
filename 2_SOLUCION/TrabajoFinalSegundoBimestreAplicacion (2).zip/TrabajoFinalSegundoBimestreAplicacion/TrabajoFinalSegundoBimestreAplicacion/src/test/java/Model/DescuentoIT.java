package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class DescuentoIT {

    
    @Test
    public void testGetDescuento() {
        // Creamos una subclase anónima de Descuento que devuelve 0.0
        Descuento descuento = new Descuento() {
            @Override
            public double getDescuento() {
                return 0.0;
            }
        };

        double expected = 0.0;
        double actual = descuento.getDescuento();
        assertEquals("El descuento debe ser 0.0", expected, actual, 1e-6);
    }
}
