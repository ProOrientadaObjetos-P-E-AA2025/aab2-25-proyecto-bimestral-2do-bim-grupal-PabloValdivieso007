package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class DescuentoNingunoIT {

    
    @Test
    public void testGetDescuento() {
        DescuentoNinguno instance = new DescuentoNinguno();
        double expected = 0.0;
        double actual = instance.getDescuento();
        assertEquals("DescuentoNinguno debería ser 0.0", expected, actual, 1e-6);
    }
}
