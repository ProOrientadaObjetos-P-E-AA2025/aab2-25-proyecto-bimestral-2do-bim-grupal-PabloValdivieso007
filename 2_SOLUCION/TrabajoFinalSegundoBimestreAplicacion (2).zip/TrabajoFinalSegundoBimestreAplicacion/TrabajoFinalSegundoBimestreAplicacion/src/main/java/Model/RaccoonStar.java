package Model;
public class RaccoonStar {
    private final double precio_plan=16.0;
    public double getprecio(){
        return precio_plan;
    }
}
