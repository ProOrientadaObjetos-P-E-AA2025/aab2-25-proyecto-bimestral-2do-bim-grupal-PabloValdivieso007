package Model;
public class OnlineRaccoon {
    private final double precio_plan=16.4;
    public double getprecio(){
        return precio_plan;
    }
}
