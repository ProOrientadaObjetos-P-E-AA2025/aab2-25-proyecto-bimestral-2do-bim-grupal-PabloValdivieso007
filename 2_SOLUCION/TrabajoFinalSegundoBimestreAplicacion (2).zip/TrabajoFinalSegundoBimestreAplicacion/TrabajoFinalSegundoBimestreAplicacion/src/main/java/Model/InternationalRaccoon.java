package Model;
public class InternationalRaccoon {
    private final double precio_plan=15.00;
    public double getprecio(){
        return precio_plan;
    }
}
