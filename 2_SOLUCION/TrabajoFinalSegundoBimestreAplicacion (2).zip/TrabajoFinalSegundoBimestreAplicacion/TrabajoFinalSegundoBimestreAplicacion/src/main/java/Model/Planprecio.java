package Model;
public class Planprecio {
    public double getprecioplanes(String plan1, String plan2) {
        Racconomic e = new Racconomic();
        RaccoonStar s = new RaccoonStar();
        OnlineRaccoon o = new OnlineRaccoon();
        InternationalRaccoon i = new InternationalRaccoon();
        double precio1, precio2;
        //-, Raccoonomic $13.50, RaccoonStar $16.00, Online Raccoon $16.40, Internacional Raccoon $15.00
        switch (plan1) {
            case "Raccoonomic $13.50" -> precio1=e.getprecio();
            case "RaccoonStar $16.00" -> precio1=s.getprecio();
            case "Online Raccoon $16.40" -> precio1=o.getprecio();
            case "Internacional Raccoon $15.00" -> precio1=i.getprecio();
            default -> precio1=0.00;
        }
        //-, Raccoonomic $13.50, RaccoonStar $16.00, Online Raccoon $16.40, Internacional Raccoon $15.00
        switch (plan2) {
            case "Raccoonomic $13.50" -> precio2=e.getprecio();
            case "RaccoonStar $16.00" -> precio2=s.getprecio();
            case "Online Raccoon $16.40" -> precio2=o.getprecio();
            case "Internacional Raccoon $15.00" -> precio2=i.getprecio();
            default -> precio2=0.00;
        }
        return precio1 + precio2;
    }
}