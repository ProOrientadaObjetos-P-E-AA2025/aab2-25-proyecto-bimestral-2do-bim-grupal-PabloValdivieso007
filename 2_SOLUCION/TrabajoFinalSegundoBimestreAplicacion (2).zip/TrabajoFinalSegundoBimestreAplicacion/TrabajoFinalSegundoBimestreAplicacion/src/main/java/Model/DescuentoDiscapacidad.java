package Model;
public class DescuentoDiscapacidad extends Descuento {
    @Override
    public double getDescuento() {
        return 0.25;
    }
}