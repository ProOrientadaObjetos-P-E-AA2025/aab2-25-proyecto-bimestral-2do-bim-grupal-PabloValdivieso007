package Model;
public class DescuentoMayorEdad extends Descuento {
    @Override
    public double getDescuento() {
        return 0.50;
    }
}