package Model;
public class Total {
    private final double iva=1.15;
    private double subtotal;
    public Total(double subtotal) {
        this.subtotal = subtotal;
    }
    public double calcularTotal(){
        return subtotal*iva;
    }
}
