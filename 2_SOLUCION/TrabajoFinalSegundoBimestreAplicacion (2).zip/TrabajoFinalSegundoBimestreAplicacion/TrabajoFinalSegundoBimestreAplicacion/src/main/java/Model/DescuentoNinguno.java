package Model;
public class DescuentoNinguno extends Descuento {
    @Override
    public double getDescuento() {
        return 0.0;
    }
}