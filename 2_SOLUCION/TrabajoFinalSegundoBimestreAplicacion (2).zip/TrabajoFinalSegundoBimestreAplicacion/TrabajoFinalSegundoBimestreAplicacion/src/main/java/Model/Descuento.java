package Model;
public abstract class Descuento {
    public abstract double getDescuento();
}