package Model;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Cliente implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre, cedula, fecha_nac, ciudad, direccion, numTel;
    private String marca, modelo, discapacidad, plan1, plan2;
    private double subtotal, total;
    public Cliente() {}
    public Cliente(Long id, String nombre, String cedula, String fecha_nac, String ciudad,
                   String direccion, String numTel, String marca, String modelo,
                   String discapacidad, String plan1, String plan2, double subtotal, double total) {
        this.id = id;
        this.nombre = nombre;
        this.cedula = cedula;
        this.fecha_nac = fecha_nac;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.numTel = numTel;
        this.marca = marca;
        this.modelo = modelo;
        this.discapacidad = discapacidad;
        this.plan1 = plan1;
        this.plan2 = plan2;
        this.subtotal=subtotal;
        this.total=total;
    }
    public Cliente(String nombre, String id, String fecha_nac, String ciudad, String direccion, String numTel, String marca, String modelo, String discapacidad, String plan1, String plan2, double subtotal, double total) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getFecha_nac() { return fecha_nac; }
    public void setFecha_nac(String fecha_nac) { this.fecha_nac = fecha_nac; }

    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getNumTel() { return numTel; }
    public void setNumTel(String numTel) { this.numTel = numTel; }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getDiscapacidad() { return discapacidad; }
    public void setDiscapacidad(String discapacidad) { this.discapacidad = discapacidad; }

    public String getPlan1() { return plan1; }
    public void setPlan1(String plan1) { this.plan1 = plan1; }

    public String getPlan2() { return plan2; }
    public void setPlan2(String plan2) { this.plan2 = plan2; }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
}
