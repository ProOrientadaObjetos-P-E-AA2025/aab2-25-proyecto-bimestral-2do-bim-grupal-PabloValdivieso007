package Model;
public class Racconomic {
    private final double precio_plan=13.5;
    public double getprecio(){
        return precio_plan;
    }
}
