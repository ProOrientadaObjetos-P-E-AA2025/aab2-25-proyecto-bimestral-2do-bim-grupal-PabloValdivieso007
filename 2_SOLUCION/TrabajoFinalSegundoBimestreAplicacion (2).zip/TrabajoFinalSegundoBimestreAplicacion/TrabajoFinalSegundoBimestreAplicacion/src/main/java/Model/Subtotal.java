package Model;
public class Subtotal {
    private Planprecio planprecio = new Planprecio();
    public double calcularSubtotal(String plan1, String plan2, int edad, boolean discapacidad) {
        Descuento descuento;
        if (edad >= 65 && discapacidad)        descuento = new DescuentoAmbas();
        else if (edad >= 65)                   descuento = new DescuentoMayorEdad();
        else if (discapacidad)                 descuento = new DescuentoDiscapacidad();
        else                                   descuento = new DescuentoNinguno();
        double precioBruto=planprecio.getprecioplanes(plan1,plan2);
        return precioBruto-(precioBruto*descuento.getDescuento());
    }
}