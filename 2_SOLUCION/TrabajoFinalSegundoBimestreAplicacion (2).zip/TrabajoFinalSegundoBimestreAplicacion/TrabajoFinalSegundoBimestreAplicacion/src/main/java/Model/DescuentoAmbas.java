package Model;
public class DescuentoAmbas extends Descuento {
    @Override
    public double getDescuento() {
        return 0.75;
    }
}