package Controller;

import Model.Cliente;

public class ControladoraLogica {
    ControladoraPersistencia controlPersis=new ControladoraPersistencia();

    public void guardar(String ciudad, String direccion, String fecha_nac, String id, String marca, String modelo, String nombre, String numTel, String discapacidad, String plan1, String plan2, double subtotal, double total) {
        Cliente cliente=new Cliente();
        cliente.setNombre(nombre);
        cliente.setCedula(id);
        cliente.setCiudad(ciudad);
        cliente.setDireccion(direccion);
        cliente.setDiscapacidad(discapacidad);
        cliente.setFecha_nac(fecha_nac);
        cliente.setMarca(marca);
        cliente.setModelo(modelo);
        cliente.setNumTel(numTel);
        cliente.setPlan1(plan1);
        cliente.setPlan2(plan2);
        cliente.setSubtotal(subtotal);
        cliente.setTotal(total);
        //delegar la persistencia del cliente a controladorapersistencia
        controlPersis.guardar(cliente);
    }
}
