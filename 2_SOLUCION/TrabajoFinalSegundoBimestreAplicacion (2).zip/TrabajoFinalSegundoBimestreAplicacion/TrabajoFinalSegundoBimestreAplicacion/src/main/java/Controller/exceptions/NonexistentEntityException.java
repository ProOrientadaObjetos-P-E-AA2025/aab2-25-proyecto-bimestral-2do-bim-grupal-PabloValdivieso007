package Controller.exceptions;
//es un exception chequeada que sirve para identificar cuando intentas editar o eliminar un registro que ya no existe en la base de datos
public class NonexistentEntityException extends Exception {
    public NonexistentEntityException(String message, Throwable cause) {
        super(message, cause);
    }
    public NonexistentEntityException(String message) {
        super(message);
    }
}
