package Controller;
import Controller.exceptions.NonexistentEntityException;
import Model.Cliente;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
public class ClienteJpaController implements Serializable {

    public ClienteJpaController() {
        //Se conecta a la unidad de persistencia "RaccoonMovilPU"
        this.emf = Persistence.createEntityManagerFactory("RaccoonMovilPU");
    }
    private EntityManagerFactory emf = null;
//Método auxiliar para obtener un EntityManager nuevo
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
//crea e inserta un nuevo cliente en la db
    public void create(Cliente cliente) {
        EntityManager em = null;
        try {
            em = getEntityManager();//abre contexto
            em.getTransaction().begin();//incia transaccion
            em.persist(cliente);//marca el objeto para inserta
            em.getTransaction().commit();//confirma cambios
        } finally {
            if (em != null) {
                em.close();//libera recursos 
            }
        }
    }
    //actualiza un cliente existente
    public void edit(Cliente cliente) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            cliente = em.merge(cliente);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = cliente.getId();
                if (findCliente(id) == null) {
                    throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    //elimina un cliente por su ID 
    public void destroy(Long id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente;
            try {
                cliente = em.getReference(Cliente.class, id);
                cliente.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.", enfe);
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    //devuelve todos los clientes guardados 
    public List<Cliente> findClienteEntities() {
        return findClienteEntities(true, -1, -1);
    }
    //devuelve un subconjunto de clientes
    public List<Cliente> findClienteEntities(int maxResults, int firstResult) {
        return findClienteEntities(false, maxResults, firstResult);
    }
    private List<Cliente> findClienteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cliente.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }
    //busca cliente por su llave primaria id
    public Cliente findCliente(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }
    //cuenta cuantos clientes hay
    public int getClienteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cliente> rt = cq.from(Cliente.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    //alternativa manual para crear cliente
    public void crearCliente(Cliente cliente) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        } finally {
            if (em.isOpen()) em.close();
        }
    }
}
