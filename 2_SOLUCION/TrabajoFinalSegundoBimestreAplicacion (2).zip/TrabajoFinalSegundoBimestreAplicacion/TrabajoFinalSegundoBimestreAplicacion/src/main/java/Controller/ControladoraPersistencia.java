package Controller;

import Model.Cliente;

public class ControladoraPersistencia {
    ClienteJpaController clientjpa=new ClienteJpaController();
//recibe un objeto Cliente ya poblado y lo persiste en la BD
    void guardar(Cliente cliente) {
        // create() abre transacción, hace persist(cliente) y commit automáticamente
        clientjpa.create(cliente);
    }
}
