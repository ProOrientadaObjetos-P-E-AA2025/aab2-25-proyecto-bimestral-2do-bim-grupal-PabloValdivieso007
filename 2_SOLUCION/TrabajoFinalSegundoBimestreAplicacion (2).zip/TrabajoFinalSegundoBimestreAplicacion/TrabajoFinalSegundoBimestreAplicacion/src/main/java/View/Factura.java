package View;
import Controller.ClienteJpaController;
import Model.Cliente;
import Model.Planprecio;
import java.util.List;
import java.awt.Desktop;
import java.io.File;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import java.io.IOException;
public class Factura extends javax.swing.JFrame {
    private Cliente clienteActual;
    public Factura() {
        initComponents();
        cargarDatosFactura();
    }
    private void cargarDatosFactura(){
        try {
            ClienteJpaController jpa=new ClienteJpaController();//obtinee todos los clientes registrados en la db
            List<Cliente> lista=jpa.findClienteEntities();
            if(lista!=null&&!lista.isEmpty()){//verifica que la lista no este vacia
                Cliente c=lista.get(lista.size()-1);//toma el ultimo cliente ingresado
                this.clienteActual = c;//almacena para usarlo al generar el pdf
                jTextArea1.append("========================================\n");
                jTextArea1.append("     Número de Factura: "+c.getId()+"\n");
                jTextArea1.append("========================================\n\n");
                jTextArea1.append("Datos del Cliente\n");
                jTextArea1.append("  Nombre    : "+c.getNombre()+"\n");
                jTextArea1.append("  Cedula    : "+c.getCedula()+"\n");
                jTextArea1.append("  Telefono  : "+c.getNumTel()+"\n");
                jTextArea1.append("  Direccion : "+c.getDireccion()+"\n\n");
                jTextArea1.append("Detalle de Planes\n");
                jTextArea1.append("  Plan(es)  : "+c.getPlan1());
                if(c.getPlan2()!=null&&!c.getPlan2().isEmpty())
                    jTextArea1.append(", "+c.getPlan2());
                jTextArea1.append("\n\n");
                double precioPlanes=new Planprecio().getprecioplanes(c.getPlan1(),c.getPlan2());
                jTextArea1.append("Totales\n");
                jTextArea1.append("  Precio Planes : "+precioPlanes+"\n");
                jTextArea1.append("  Subtotal      : "+c.getSubtotal()+"\n");
                jTextArea1.append("  Total (IVA)   : "+c.getTotal()+"\n");
            } else {
                jTextArea1.append("No hay facturas en la base de datos.\n");
            }
        } catch(Exception ex) {
            ex.printStackTrace();
            jTextArea1.append("Error al cargar datos de factura.\n");
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnSalir = new javax.swing.JButton();
        btnGuardarPDF = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Swis721 Blk BT", 0, 36)); // NOI18N
        jLabel1.setText("Factura");

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\logo pequeño.png")); // NOI18N
        jLabel2.setText("jLabel2");

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\letras logo pequeñas.png")); // NOI18N
        jLabel3.setText("jLabel2");

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        btnSalir.setFont(new java.awt.Font("Swis721 Blk BT", 0, 12)); // NOI18N
        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnGuardarPDF.setFont(new java.awt.Font("Swis721 Blk BT", 0, 12)); // NOI18N
        btnGuardarPDF.setText("Guardar PDF de la Factura");
        btnGuardarPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarPDFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(btnGuardarPDF)
                        .addGap(18, 18, 18)
                        .addComponent(btnSalir)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarPDF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnGuardarPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarPDFActionPerformed
        try {
            String texto = jTextArea1.getText();//obtiene el texto
            String ruta = "factura_" + clienteActual.getId() + ".pdf";//nombre usando ID
            PdfWriter writer = new PdfWriter(ruta);//crea el escritor
            PdfDocument pdf = new PdfDocument(writer);//inicializa el doccumento sobre ese escritor
            Document doc = new Document(pdf);
            for (String linea : texto.split("\\n")) {//recorre cada linea de texto
                doc.add(new Paragraph(linea));//añade esa linea al pdf
            }            
            doc.close();//cierra docuemento 
            if (Desktop.isDesktopSupported()) {//SI el sistema soporta desktop abre el pdf
                Desktop.getDesktop().open(new File(ruta));
            }
        } catch (IOException e) {//si hay fallo imprime el listado de lineas por las que hay un error en el funcionamiento
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnGuardarPDFActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardarPDF;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}