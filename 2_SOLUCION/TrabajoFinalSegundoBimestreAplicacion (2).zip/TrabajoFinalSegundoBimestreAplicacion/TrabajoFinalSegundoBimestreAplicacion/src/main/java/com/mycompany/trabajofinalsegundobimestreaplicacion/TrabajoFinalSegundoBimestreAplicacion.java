package com.mycompany.trabajofinalsegundobimestreaplicacion;
import View.Inicio;
public class TrabajoFinalSegundoBimestreAplicacion {
    public static void main(String[] args) {
        Inicio start=new Inicio();
        start.setVisible(true);
        start.setLocationRelativeTo(null);
    }
}
